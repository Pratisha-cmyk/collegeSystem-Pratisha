package com.garbageManagement.model;

/**
 * LoginModel represents the user credentials for login.
 */
public class LoginModel {
    private String username;
    private String password;

    /**
     * Constructs a LoginModel with the specified username and password.
     *
     * @param username the username entered by the user
     * @param password the password entered by the user
     */
    public LoginModel(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * Returns the username.
     *
     * @return the username entered by the user
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username.
     *
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Returns the password.
     *
     * @return the password entered by the user
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password.
     *
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
