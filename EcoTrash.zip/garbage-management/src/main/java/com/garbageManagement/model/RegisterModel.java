package com.garbageManagement.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class RegisterModel {
	private String fullName;
	private String username;
	private String gender;
	private LocalDate dob;
	private String phoneNumber;
	private String password;
	private String profilePicture;
	private LocalDateTime createdAt;

	public RegisterModel() {
		// Default constructor
	}

	public RegisterModel(String fullName, String username, String gender, LocalDate dob, String phoneNumber, String password, String profilePicture, LocalDateTime createdAt) {
		this.fullName = fullName;
		this.username = username;
		this.gender = gender;
		this.dob = dob;
		this.phoneNumber = phoneNumber;
		this.password = password;
		this.profilePicture = profilePicture;
		this.createdAt = createdAt;
	}

	// Getters and Setters
	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProfilePicture() {
		return profilePicture;
	}

	public void setProfilePicture(String profilePicture) {
		this.profilePicture = profilePicture;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
}
