package com.garbageManagement.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import com.garbageManagement.model.RegisterModel;
import com.garbageManagement.service.RegisterService;
import com.garbageManagement.util.ImageUtil;
import com.garbageManagement.util.PasswordUtil;
import com.garbageManagement.util.ValidationUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

/**
 * RegisterController handles user registration for the Garbage Management System.
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/register" })
@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
		maxFileSize = 1024 * 1024 * 10, // 10MB
		maxRequestSize = 1024 * 1024 * 50) // 50MB
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private final ImageUtil imageUtil = new ImageUtil();
	private final RegisterService registerService = new RegisterService();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/WEB-INF/pages/register.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String validationMessage = validateRegistrationForm(req);
			if (validationMessage != null) {
				handleError(req, resp, validationMessage);
				return;
			}

			RegisterModel registerModel = extractRegisterModel(req);
			Boolean isAdded = registerService.addUser(registerModel);

			if (isAdded == null) {
				handleError(req, resp, "Server error. Please try again later.");
			} else if (isAdded) {
				if (uploadImage(req)) {
					handleSuccess(req, resp, "Account successfully created!", "/WEB-INF/pages/login.jsp");
				} else {
					handleError(req, resp, "Image upload failed. Try again.");
				}
			} else {
				handleError(req, resp, "Registration failed. Please try again later.");
			}
		} catch (Exception e) {
			handleError(req, resp, "Unexpected error. Please try again later.");
			e.printStackTrace();
		}
	}

	private String validateRegistrationForm(HttpServletRequest req) {
		String fullName = req.getParameter("fullName");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String retypePassword = req.getParameter("retypePassword");
		String gender = req.getParameter("gender");
		String dobStr = req.getParameter("dob");
		String contact = req.getParameter("contact");

		if (ValidationUtil.isNullOrEmpty(fullName)) return "Full name is required.";
		if (ValidationUtil.isNullOrEmpty(username)) return "Username is required.";
		if (ValidationUtil.isNullOrEmpty(password)) return "Password is required.";
		if (ValidationUtil.isNullOrEmpty(retypePassword)) return "Retype your password.";
		if (ValidationUtil.isNullOrEmpty(gender)) return "Gender is required.";
		if (ValidationUtil.isNullOrEmpty(dobStr)) return "Date of birth is required.";
		if (ValidationUtil.isNullOrEmpty(contact)) return "Contact number is required.";

		LocalDate dob;
		try {
			dob = LocalDate.parse(dobStr);
		} catch (Exception e) {
			return "Invalid date format.";
		}

		if (!ValidationUtil.isAlphanumericStartingWithLetter(username))
			return "Username must start with a letter and be alphanumeric.";
		if (!ValidationUtil.isValidGender(gender))
			return "Gender must be 'male' or 'female'.";
		if (!ValidationUtil.isValidPhoneNumber(contact))
			return "Phone number must be 10 digits and start with 98.";
		if (!ValidationUtil.isValidPassword(password))
			return "Password must be 8+ characters, with uppercase, number, and symbol.";
		if (!ValidationUtil.doPasswordsMatch(password, retypePassword))
			return "Passwords do not match.";
		if (!ValidationUtil.isAgeAtLeast16(dob))
			return "You must be at least 16 years old.";

		try {
			Part image = req.getPart("image");
			if (!ValidationUtil.isValidImageExtension(image))
				return "Only jpg, jpeg, png, gif images are allowed.";
		} catch (IOException | ServletException e) {
			return "Image error. Try another file.";
		}

		return null;
	}

	private RegisterModel extractRegisterModel(HttpServletRequest req) throws Exception {
		String fullName = req.getParameter("fullName");
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		String gender = req.getParameter("gender");
		LocalDate dob = LocalDate.parse(req.getParameter("dob"));
		String contact = req.getParameter("contact");

		password = PasswordUtil.encrypt(username, password);
		Part image = req.getPart("image");
		String imageUrl = imageUtil.getImageNameFromPart(image);

		return new RegisterModel(fullName, username, gender, dob, contact, password, imageUrl, LocalDateTime.now());
	}

	private boolean uploadImage(HttpServletRequest req) throws IOException, ServletException {
		Part image = req.getPart("image");
		return imageUtil.uploadImage(image, req.getServletContext().getRealPath("/"), "users");
	}

	private void handleSuccess(HttpServletRequest req, HttpServletResponse resp, String message, String redirectPage)
			throws ServletException, IOException {
		req.setAttribute("success", message);
		req.getRequestDispatcher(redirectPage).forward(req, resp);
	}

	private void handleError(HttpServletRequest req, HttpServletResponse resp, String message)
			throws ServletException, IOException {
		req.setAttribute("error", message);
		req.setAttribute("fullName", req.getParameter("fullName"));
		req.setAttribute("username", req.getParameter("username"));
		req.setAttribute("gender", req.getParameter("gender"));
		req.setAttribute("dob", req.getParameter("dob"));
		req.setAttribute("contact", req.getParameter("contact"));
		req.getRequestDispatcher("/WEB-INF/pages/register.jsp").forward(req, resp);
	}
}
