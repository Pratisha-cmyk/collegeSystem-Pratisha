package com.garbageManagement.controller;

import java.io.IOException;

import com.garbageManagement.model.LoginModel;
import com.garbageManagement.service.LoginService;
import com.garbageManagement.util.CookieUtil;
import com.garbageManagement.util.SessionUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * LoginController handles login requests for the Garbage Management System.
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/login" })
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private final LoginService loginService = new LoginService();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("/WEB-INF/pages/login.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String username = req.getParameter("username");
			String password = req.getParameter("password");

			if (isInvalid(username) || isInvalid(password)) {
				handleError(req, resp, "Username and password are required.");
				return;
			}
	}

	private boolean isInvalid(String input) {
		return input == null || input.trim().isEmpty();
	}

	private void handleError(HttpServletRequest req, HttpServletResponse resp, String errorMessage)
			throws ServletException, IOException {
		req.setAttribute("error", errorMessage);
		req.setAttribute("username", req.getParameter("username"));
		req.getRequestDispatcher("/WEB-INF/pages/login.jsp").forward(req, resp);
	}
}
