package com.garbageManagement.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.garbageManagement.config.DbConfig;
import com.garbageManagement.model.LoginModel;
import com.garbageManagement.util.PasswordUtil;

/**
 * LoginService handles login logic for users in the Garbage Management System.
 */
public class LoginService {

    /**
     * Authenticates the user based on username and password.
     *
     * @param loginModel LoginModel containing username and password
     * @return true if login successful, false if invalid credentials, null if server error
     */
    public Boolean loginUser(LoginModel loginModel) {
        String sql = "SELECT password FROM users WHERE username = ?";

        try (Connection conn = DbConfig.getDbConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, loginModel.getUsername());
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String encryptedPassword = rs.getString("password");
                String inputPassword = PasswordUtil.encrypt(loginModel.getUsername(), loginModel.getPassword());

                return encryptedPassword.equals(inputPassword);
            }

            return false; // username not found
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return null; // server/db error
        }
    }
}
