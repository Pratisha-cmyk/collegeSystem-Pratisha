<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Account - Garbage Management System</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/registration.css">
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <h1>Garbage Management System</h1>
            <p>Join our mission for cleaner communities</p>
            <ul>
                <li>Real-time waste collection tracking</li>
                <li>Optimized collection routes</li>
                <li>Environmental impact reports</li>
                <li>Community rewards program</li>
            </ul>
        </div>

        <div class="right-panel">
            <form class="form-box" action="/register" method="post">
                <div class="form-header">
                    <div class="logo-circle"></div>
                    <h2>Create Your Account</h2>
                    <p>Please fill in your information below</p>
                </div>

                <div class="form-group">
                    <label>Full Name*</label>
                    <input type="text" name="fullname" placeholder="Enter your full name" required>
                </div>

                <div class="form-group">
                    <label>Username*</label>
                    <input type="text" name="username" placeholder="Choose a username" required>
                </div>

                <div class="form-group">
                    <label>Email Address*</label>
                    <input type="email" name="email" placeholder="Enter your email address" required>
                </div>

                <div class="form-group">
                    <label>Password*</label>
                    <input type="password" name="password" placeholder="********" required>
                    <small>Password must be at least 8 characters with numbers and symbols</small>
                </div>

                <div class="form-group">
                    <label>Gender</label>
                    <select name="gender" required>
                        <option value="">Select gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                        <option value="Prefer not to say">Prefer not to say</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Contact Number</label>
                    <input type="text" name="contact" placeholder="Enter your phone number">
                </div>

                <div class="form-group checkbox-group">
                    <input type="checkbox" required>
                    <label>I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></label>
                </div>

                <button type="submit" class="submit-btn">Create Account</button>

                <p class="bottom-text">Already have an account? <a href="login.jsp">Log in</a></p>
            </form>
        </div>
    </div>
</body>
</html>
