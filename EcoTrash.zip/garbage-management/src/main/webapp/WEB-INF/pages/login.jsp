<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Registration Form</title>
  <link rel="stylesheet" href="${pageContext.request.contextPath}/css/login.css" />
</head>
<body>
  <div class="container">
    <!-- Left Green Panel -->
    <div class="left-panel">
      <div class="left-content">
        <h1>Garbage Management System</h1>
        <hr />
        <p>Smart solutions for a cleaner tomorrow</p>
      </div>
    </div>

    <!-- Right Login Form -->
    <div class="right-panel">
      <div class="form-container">
        <div class="logo-circle"></div>
        <h2>Welcome Back</h2>
        <p class="login-text">Please log in to your account</p>

        <form>
          <input type="email" placeholder="Email address" required />
          <input type="password" placeholder="Password" required />

          <div class="options">
            <label><input type="checkbox" /> Remember me</label>
            <a href="#">Forgot password?</a>
          </div>

          <button type="submit" class="login-btn">Log In</button>

          <p class="or">Or continue with</p>
          <div class="social-buttons">
            <button type="button">G</button>
            <button type="button">f</button>
            <button type="button">in</button>
          </div>

          <p class="signup">Don't have an account? <a href="#">Sign up</a></p>
        </form>

        <footer>
          <small>&copy; 2025 Garbage Management System. All rights reserved.</small>
        </footer>
      </div>
    </div>
  </div>
</body>
</html>
